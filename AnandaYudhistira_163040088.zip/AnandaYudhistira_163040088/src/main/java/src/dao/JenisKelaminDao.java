package src.dao;

import src.db.MySqlConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.List;
import java.util.ArrayList;
import src.model.JenisKelamin;

/**
 *
 * @author anand
 */
public class JenisKelaminDao {
    
    public int insert(JenisKelamin jenisKelamin){
        int result = -1;
        try (Connection conn = MySqlConnection.getInstance().getConnection()){
            PreparedStatement state = conn.prepareStatement("Insert into jenis_kelamin (id,jenis_kelamin) values(?, ?)");
            state.setString(1, jenisKelamin.getId());
            state.setString(2, jenisKelamin.getJenisKelamin());
            result = state.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }
    
    public int delete(JenisKelamin jenisKelamin){
        int result = -1;
        try (Connection conn = MySqlConnection.getInstance().getConnection()){
            PreparedStatement state = conn.prepareStatement("delete from jens_kelamin where id = ?");
            state.setString(1, jenisKelamin.getId());
            result = state.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }
    
    public List<JenisKelamin> findAll(){
        List<JenisKelamin> list = new ArrayList<>();
        try (Connection conn = MySqlConnection.getInstance().getConnection(); Statement state = conn.createStatement()){
            try (ResultSet resultSet = state.executeQuery("selecet* from jenis_kelamin")){
              while(resultSet.next())  {
                  JenisKelamin jenisKelamin = new JenisKelamin();
                  jenisKelamin.setId(resultSet.getString("id"));
                  jenisKelamin.setJenisKelamin(resultSet.getString("jenis_kelamin"));
                  list.add(jenisKelamin);
              }
            } catch (Exception e) {
                e.printStackTrace();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
}
