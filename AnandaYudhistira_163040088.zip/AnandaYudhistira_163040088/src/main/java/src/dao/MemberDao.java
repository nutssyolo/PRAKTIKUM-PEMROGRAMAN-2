package src.dao;

import src.db.MySqlConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
import java.util.List;
import java.util.ArrayList;
import src.model.JenisKelamin;
import src.model.Member;

/**
 *
 * @author anand
 */
public class MemberDao {
    public int insert(Member member){
        int result = -1;
        try (Connection conn = MySqlConnection.getInstance().getConnection()){
            PreparedStatement state = conn.prepareStatement("Insert into Member (id,nama,jenis_kelamin_id,no_hp,alamat) value(?,?,?,?,?)");
            state.setString(1, member.getId());
            state.setString(2, member.getNama());
            state.setString(3, member.getJk().getId());
            state.setString(3, member.getNoHP());
            state.setString(4, member.getAlamat());
            result = state.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }
    
    public int delete(Member member){
        int result = -1;
        try (Connection conn = MySqlConnection.getInstance().getConnection()){
            PreparedStatement state = conn.prepareStatement("delete from member where id = ?");
            state.setString(1, member.getId());
            result = state.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }
    
    public List<Member> findAll(){
        List<Member> list = new ArrayList<>();
        try (Connection conn = MySqlConnection.getInstance().getConnection(); Statement state = conn.createStatement()){
            try (ResultSet resultSet = state.executeQuery("selecet member.id, member.nama, jenis_kelamin.id jenis_kelamin_id, jenis_kelamin.jenis_kelamin, member.no_hp, member.alamat"
                    + "from member join jenis_kelamin on jenis_kelamin.id = member.jenis_kelamin_id")){
              while(resultSet.next())  {
                  Member member = new Member();
                  member.setId(resultSet.getString("id"));
                  member.setNama(resultSet.getString("nama"));
                  member.setNoHP(resultSet.getString("no_hp"));
                  member.setAlamat(resultSet.getString("alamat"));
                  
                  JenisKelamin jenisKelamin = new JenisKelamin();
                  jenisKelamin.setId(resultSet.getString("jenis_member_id"));
                  jenisKelamin.setJenisKelamin(resultSet.getString("jenis_kelamin"));
                  member.setJk(jenisKelamin);
                  list.add(member);
              }
            } catch (Exception e) {
                e.printStackTrace();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
}
