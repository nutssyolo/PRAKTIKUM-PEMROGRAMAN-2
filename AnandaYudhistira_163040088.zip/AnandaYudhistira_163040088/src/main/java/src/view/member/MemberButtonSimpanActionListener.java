/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package src.view.member;

import src.model.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import src.dao.MemberDao;
//import view.jeniskelamin.JenisKelaminFrame;

/**
 *
 * @author anand
 */
public class MemberButtonSimpanActionListener implements ActionListener{
    private MemberFrame memberFrame;
    private MemberDao memberDao;

    public MemberButtonSimpanActionListener(MemberFrame memberFrame, MemberDao memberDao) {
     this.memberFrame = memberFrame;
     this.memberDao = memberDao;
    }
       
    @Override
    public void actionPerformed(ActionEvent e) {
        String nama = this.memberFrame.getNama();
        JenisKelamin jk = this.memberFrame.getJenisKelamin();
        String noHP = this.memberFrame.getNoHP();
        String alamat = this.memberFrame.getAlamat();
        
        if (nama.isEmpty()) {
            this.memberFrame.showAlert("Nama Tidak Boleh Kosong");
        } else if (noHP.isEmpty()){
            this.memberFrame.showAlert("No.HP Tidak Boleh Kosong");
        } else if (alamat.isEmpty()){
            this.memberFrame.showAlert("Alamat Tidak Boleh Kosong");
        } else {
            Member member = new Member();
            member.setNama(nama);
            member.setJk(jk);
            member.setNoHP(noHP);
            member.setAlamat(alamat);

            this.memberFrame.addMember(member);
            this.memberDao.insert(member);
        }
        
        
    }
    
}
