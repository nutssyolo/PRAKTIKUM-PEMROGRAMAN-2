/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package src.view.member;

import java.util.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.*;
import src.dao.JenisKelaminDao;
import src.model.*;
import src.dao.*;

/**
 *
 * @author anand
 */

public class MemberFrame extends JFrame{
   private List<JenisKelamin>  jenisKelaminList;
   private List<Member>  memberList;
   private JTextField textFieldNama, textFieldNoHP;
   private MemberTableModel tableModel;
   private JComboBox comboJenis;
   private JTextArea txtAlamat;
   private MemberDao memberDao;
   private JenisKelaminDao jenisKelaminDao;
   
   public MemberFrame(MemberDao memberDao, JenisKelaminDao jenisKelaminDao){
       this.jenisKelaminList = jenisKelaminDao.findAll();
       this.memberList = this.memberDao.findAll();
       
       this.memberDao = memberDao;
       this.jenisKelaminDao = jenisKelaminDao;
       
       this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
       
       JLabel lblNama = new JLabel("Nama : ");
       lblNama.setBounds(15, 40, 350, 10);
       
       textFieldNama = new JTextField();
       textFieldNama.setBounds(15, 60, 350, 30);
       
       JLabel lblNoHP = new JLabel("No HP : ");
       lblNoHP.setBounds(15, 100, 350, 10);
       
       textFieldNoHP = new JTextField();
       textFieldNoHP.setBounds(15, 120, 350, 30);
       
       JLabel lblAlamat = new JLabel("No HP : ");
       lblAlamat.setBounds(15, 160, 350, 10);
       
       txtAlamat = new JTextArea();
       txtAlamat.setBounds(15, 180, 350, 30);
       
       JLabel lblJenisKelamin = new JLabel("Jenis Kemalin : ");
       lblJenisKelamin.setBounds(15, 200, 350, 10);
       
       comboJenis = new JComboBox();
       comboJenis.setBounds(15, 220, 350, 30);
       comboJenis.addItem(jenisKelaminList);
       
       JButton button = new JButton("Simpan");
       button.setBounds(15,250,350,40);
       
       javax.swing.JTable table = new JTable();
       JScrollPane scrollableTable = new JScrollPane(table);
       scrollableTable.setBounds(15, 280, 350, 130);
       
       tableModel= new MemberTableModel(memberList);
       table.setModel(tableModel);
       
       MemberButtonSimpanActionListener actionListener = new MemberButtonSimpanActionListener(this,memberDao);
       button.addActionListener(actionListener);
       
       this.add(button);
       this.add(textFieldNama);
       this.add(textFieldNoHP);
       this.add(lblNama);
       this.add(lblNoHP);
       this.add(lblJenisKelamin);
       this.add(scrollableTable);
       
       this.setSize(400,500);
       this.setLayout(null);
   }

public void populateComboJenis(){
    this.jenisKelaminList = this.jenisKelaminDao.findAll();
    for(JenisKelamin jenisKelamin: this.jenisKelaminList){
        comboJenis.addItem(jenisKelamin.getJenisKelamin());
    }
}

public String getNama(){
    return textFieldNama.getText();
}

public String getNoHP(){
    return textFieldNoHP.getText();
}

public String getAlamat(){
    return txtAlamat.getText();
}

public JenisKelamin getJenisKelamin(){
    return jenisKelaminList.get(comboJenis.getSelectedIndex());
}

public void addMember(Member member){
    tableModel.add(member);
    textFieldNama.setText("");
    textFieldNoHP.setText("");
}

public void showAlert(String message){
    JOptionPane.showMessageDialog(this, message);
}

}