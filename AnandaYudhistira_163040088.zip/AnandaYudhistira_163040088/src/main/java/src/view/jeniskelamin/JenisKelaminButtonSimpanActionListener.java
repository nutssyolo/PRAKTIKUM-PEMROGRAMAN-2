/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package src.view.jeniskelamin;
import java.util.UUID;
import java.awt.event.*;
import src.model.JenisKelamin;
import src.dao.JenisKelaminDao;

/**
 *
 * @author anand
 */

public class JenisKelaminButtonSimpanActionListener implements ActionListener{
    private JenisKelaminFrame jenisKelaminFrame;
    private JenisKelaminDao jenisKelaminDao;

    public JenisKelaminButtonSimpanActionListener(JenisKelaminFrame jenisKelaminFrame, JenisKelaminDao jenisKelaminDao) {
     this.jenisKelaminFrame = jenisKelaminFrame;
     this.jenisKelaminDao = jenisKelaminDao;
    }
       
    @Override
    public void actionPerformed(ActionEvent e) {
        String jk = this.jenisKelaminFrame.getJenisKelamin();
        JenisKelamin jenisKelamin = new JenisKelamin();
        jenisKelamin.setId(UUID.randomUUID().toString());
        jenisKelamin.setJenisKelamin(jk);
        
        this.jenisKelaminFrame.addJenisKelamin(jenisKelamin);
        this.jenisKelaminDao.insert(jenisKelamin);
    }
    
}
