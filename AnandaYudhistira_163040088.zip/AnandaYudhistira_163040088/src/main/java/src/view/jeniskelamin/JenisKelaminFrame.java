/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package src.view.jeniskelamin;

import java.awt.event.*;
import javax.swing.*;
import javax.swing.table.*;
import java.util.*;
import src.model.JenisKelamin;
import src.dao.JenisKelaminDao;

/**
 *
 * @author anand
 */

public class JenisKelaminFrame extends JFrame{
   private List<JenisKelamin>  jenisKelaminList;
   private JTextField textFieldJK;
   private JenisKelaminTableModel tableModel;
   private JenisKelaminDao jenisKelaminDao;
   
   public JenisKelaminFrame(JenisKelaminDao jenisKelaminDao){
       this.jenisKelaminDao = jenisKelaminDao;
       this.jenisKelaminList = jenisKelaminDao.findAll();
       this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
       
       JLabel lblJenisKelamin = new JLabel("Jenis Kelamin : ");
       lblJenisKelamin.setBounds(15, 40, 350, 10);
       
       textFieldJK = new JTextField();
       textFieldJK.setBounds(15, 60, 350, 30);
       
       JButton button = new JButton("Simpan");
       button.setBounds(15,100,350,40);
       
       javax.swing.JTable table = new JTable();
       JScrollPane scrollableTable = new JScrollPane(table);
       scrollableTable.setBounds(15, 150, 350, 200);
       
       tableModel= new JenisKelaminTableModel(jenisKelaminList);
       table.setModel(tableModel);
       
       JenisKelaminButtonSimpanActionListener actionListener = new JenisKelaminButtonSimpanActionListener(this,jenisKelaminDao);
       button.addActionListener(actionListener);
       
       this.add(button);
       this.add(textFieldJK);
       this.add(lblJenisKelamin);
       this.add(scrollableTable);
       
       this.setSize(400,500);
       this.setLayout(null);
   }
   
   public String getJenisKelamin(){
       return textFieldJK.getText();
   }
   
   public void addJenisKelamin(JenisKelamin jenisKelamin){
       tableModel.add(jenisKelamin);
       textFieldJK.setText("");
   }
}
