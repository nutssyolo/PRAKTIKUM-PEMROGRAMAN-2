/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package src.view.jeniskelamin;
import com.tugas.main.Member;
import java.util.ArrayList;
import javax.swing.table.*;
import java.util.List;
import src.model.JenisKelamin;

/**
 *
 * @author anand
 */

public class JenisKelaminTableModel extends AbstractTableModel{
    private String[] columnNames = {"Jenis Kelamin"};
//    private ArrayList<Member> data = new ArrayList<Member>();
    private List<JenisKelamin> data;

    public JenisKelaminTableModel(List<JenisKelamin> data) {
        this.data = data;
    }
    
    public int getColumnCount(){
       return columnNames.length;
   }
   
   public int getRowCount(){
       return data.size();
   }
   
   public String getColumnName(int col){
       return columnNames[col];
   }
   
   public Object getValueAt(int row, int col){
       JenisKelamin rowItem= data.get(row);
       String value = "";
       
       switch (col)
       {
           case 0:
               value = rowItem.getJenisKelamin();
               break;
        }
       
       return value;
   }
   
   public boolean isCellEditable(int row, int col){
        return false;
    }
   
   public void add(JenisKelamin value){
        data.add(value);
        fireTableRowsInserted(data.size() - 1, data.size() - 1);
    }

//    private void fireTableRowInserted(int i, int i0) {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
//    }
}
